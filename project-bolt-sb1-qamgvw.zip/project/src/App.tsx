import React, { useState } from 'react';
import { Lock, Image as ImageIcon } from 'lucide-react';
import ClientView from './components/ClientView';
import EditorView from './components/EditorView';

function App() {
  const [isEditor, setIsEditor] = useState(false);
  const [pin, setPin] = useState('');
  const [showPinModal, setShowPinModal] = useState(false);

  const handlePinSubmit = () => {
    if (pin === '2580') {
      setIsEditor(true);
      setShowPinModal(false);
    } else {
      alert('Invalid PIN');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center space-x-2">
              <ImageIcon className="h-8 w-8 text-indigo-600" />
              <span className="text-2xl font-bold text-gray-900">Jayanth Designs</span>
            </div>
            {!isEditor && (
              <button
                onClick={() => setShowPinModal(true)}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                <Lock className="h-4 w-4 mr-2" />
                Editor Access
              </button>
            )}
          </div>
        </div>
      </nav>

      {showPinModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Enter Editor PIN</h2>
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md mb-4"
              placeholder="Enter PIN"
            />
            <div className="flex justify-end space-x-2">
              <button
                onClick={() => setShowPinModal(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800"
              >
                Cancel
              </button>
              <button
                onClick={handlePinSubmit}
                className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}

      {isEditor ? <EditorView /> : <ClientView />}
    </div>
  );
}

export default App;