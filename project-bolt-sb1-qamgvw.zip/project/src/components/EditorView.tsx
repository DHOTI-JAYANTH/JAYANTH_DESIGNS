import React, { useEffect, useState } from 'react';
import { Download, Image as ImageIcon, Phone } from 'lucide-react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';

interface Submission {
  id: string;
  imageUrl: string;
  whatsapp: string;
  date: string;
  status: 'pending' | 'completed';
}

function EditorView() {
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'submissions'), orderBy('date', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const newSubmissions = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Submission[];
      
      setSubmissions(newSubmissions);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleDownload = (imageUrl: string) => {
    window.open(imageUrl, '_blank');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="bg-white rounded-xl shadow-xl p-8 mt-8">
        <div className="flex items-center justify-center mb-8 space-x-3">
          <ImageIcon className="h-8 w-8 text-indigo-600" />
          <h1 className="text-3xl font-bold text-gray-800">
            Client Submissions
          </h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {submissions.map((submission) => (
            <div
              key={submission.id}
              className="bg-white rounded-lg shadow-lg overflow-hidden group"
            >
              <div className="relative aspect-square">
                <img
                  src={submission.imageUrl}
                  alt="Design submission"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-opacity duration-200">
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    <button
                      onClick={() => handleDownload(submission.imageUrl)}
                      className="inline-flex items-center px-4 py-2 bg-white rounded-md text-sm font-medium text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </button>
                  </div>
                </div>
              </div>
              <div className="p-4 border-t">
                <div className="flex items-center space-x-2 mb-2">
                  <Phone className="h-4 w-4 text-indigo-600" />
                  <p className="text-sm font-medium text-gray-800">
                    {submission.whatsapp}
                  </p>
                </div>
                <p className="text-sm text-gray-500">
                  Submitted: {new Date(submission.date).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))}
        </div>

        {submissions.length === 0 && (
          <div className="text-center py-12">
            <ImageIcon className="mx-auto h-12 w-12 text-gray-400" />
            <p className="mt-2 text-sm text-gray-500">No submissions yet</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default EditorView;